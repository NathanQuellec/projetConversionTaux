package conversionTaux.session;

public interface ConversionTauxCste {
	//les msg retour
    static final String RESULTAT       = "Le montant converti = ";
    static final String ACCESS_DENIED   = "Service reserve aux abonnes connectes";
    static final String NO_RESULTAT     = "Erreur de saisie. Les valeurs demandées ne sont pas trouvées";
    static final String RESULTAT_MULTIPLE   = "Conflit de données. Les valeurs recherchées existent en plusieurs exemplaires";
    static final String NO_INSERTION  = "Conflit de données. Les valeurs saisies existent déjà";
    static final String SUCCESS  = "service reussi";
}
