

Le repertoire session du serveur sans bean.