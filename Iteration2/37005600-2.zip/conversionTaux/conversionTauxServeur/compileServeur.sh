ant jar
cd build
asadmin redeploy --name conversionTauxServeur conversionTauxServeur.jar
cd ..