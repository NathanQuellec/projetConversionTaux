

Les methodes existantes de iteration1 :
public String convertir(String monnaieA, String monnaieB, double montant);
public String creerCompte(String login, String passwd);

Les methodes introduites dans iteration2 :
public String connecter(String login, String passwd);
public String ajouterFavori(String favori, String monnaieA, String monnaieB);
public String convertir(String favori, double montant);
public String deconnecter();