ant compile
cd build
java Main